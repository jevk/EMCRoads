function loadGeodata() {

chart.geodata = am4geodata_worldLow
}